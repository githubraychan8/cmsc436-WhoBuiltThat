package com.example.wbt

class Versions(val codeName: String, val image : Int, val version: String, val apiLevel: String, val description: String, var expandable: Boolean = false) {

}