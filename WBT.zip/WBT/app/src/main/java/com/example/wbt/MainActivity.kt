package com.example.wbt

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.widget.SearchView;
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {

    val versionList = ArrayList<Versions>()
    val displayList = ArrayList<Versions>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize data (i.e. add data from list of brands)
        initData()
        displayList.addAll(versionList)
        setRecyclerView()
    }

    private fun setRecyclerView() {
        val versionAdapter = VersionAdapter(displayList)
        recyclerView.adapter = versionAdapter
        recyclerView.setHasFixedSize(true)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        val menuItem = menu!!.findItem(R.id.search)

        // Search functionality
        if (menuItem != null){
            val searchView = menuItem.actionView as SearchView

            searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
                override fun onQueryTextSubmit(query: String?): Boolean {
                    return true
                }

                // When the user types in the search bar...
                override fun onQueryTextChange(newText: String?): Boolean {
                    if (newText!!.isNotEmpty()){
                        // Stop displaying all the brands
                        displayList.clear()
                        val search = newText.toLowerCase(Locale.getDefault())

                        // Start displaying only the brands that are found via the search
                        versionList.forEach{
                            if (it.codeName.toLowerCase(Locale.getDefault()).contains(search)){
                                displayList.add(it)
                            }
                        }
                        recyclerView.adapter!!.notifyDataSetChanged()
                    } else {
                        displayList.clear()
                        displayList.addAll(versionList)
                        recyclerView.adapter!!.notifyDataSetChanged()
                    }
                    return true
                }
            })
        }

        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return super.onOptionsItemSelected(item)
    }

    private fun initData() {
        // Initialize brand data / information

        // Brands under The Coca-Cola Company
        versionList.add(Versions(codeName = "Coca-Cola", version = "Atlanta, GA", apiLevel = "1892", description = "Owned by The Coca-Cola Company", image = R.drawable.coke))
        versionList.add(Versions(codeName = "Dasani", version = "Atlanta, GA", apiLevel = "1999", description = "Owned by The Coca-Cola Company", image = R.drawable.dasani))
        versionList.add(Versions(codeName = "Fanta", version = "Germany", apiLevel = "1940", description = "Owned by The Coca-Cola Company", image = R.drawable.fanta))
        versionList.add(Versions(codeName = "Fuze Tea", version = "Englewood Cliffs, NJ", apiLevel = "2000", description = "Owned by The Coca-Cola Company", image = R.drawable.fuze))
        versionList.add(Versions(codeName = "Honest Tea", version = "Bethesda, MD", apiLevel = "1998", description = "Owned by The Coca-Cola Company", image = R.drawable.honest))
        versionList.add(Versions(codeName = "Smart Water", version = "Atlanta, GA", apiLevel = "1996", description = "Owned by The Coca-Cola Company", image = R.drawable.smart))
        versionList.add(Versions(codeName = "Powerade", version = "Atlanta, GA", apiLevel = "1988", description = "Owned by The Coca-Cola Company", image = R.drawable.powerade))
        versionList.add(Versions(codeName = "Minute Maid", version = "Plymouth, FL", apiLevel = "1945", description = "Owned by The Coca-Cola Company", image = R.drawable.minutemaid))
        versionList.add(Versions(codeName = "Sprite", version = "West Germany", apiLevel = "1961", description = "Owned by The Coca-Cola Company", image = R.drawable.sprite))
        versionList.add(Versions(codeName = "Schweppes", version = "Geneva, CH", apiLevel = "1783", description = "Owned by The Coca-Cola Company", image = R.drawable.schweppes))
        versionList.add(Versions(codeName = "Vitamin Water", version = "Queens, New York", apiLevel = "2000", description = "Owned by The Coca-Cola Company", image = R.drawable.vitaminwater))

        // Brands under PepsiCo
        versionList.add(Versions(codeName = "Pepsi", version = "New Bern, NC", apiLevel = "1965", description = "Owned by PepsiCo", image = R.drawable.pepsi))
        versionList.add(Versions(codeName = "Diet Pepsi", version = "New Bern, NC", apiLevel = "1893", description = "Owned by PepsiCo", image = R.drawable.dietpepsi))
        versionList.add(Versions(codeName = "Mountain Dew", version = "Knoxville, TN", apiLevel = "1961", description = "Owned by PepsiCo", image = R.drawable.mountaindew))
        versionList.add(Versions(codeName = "Tropicana", version = "Palm Meadow, FL", apiLevel = "1947", description = "Owned by PepsiCo", image = R.drawable.tropicana))
        versionList.add(Versions(codeName = "Doritos", version = "Anaheim, CA", apiLevel = "1966", description = "Owned by PepsiCo", image = R.drawable.doritos))
        versionList.add(Versions(codeName = "7up", version = "St. Louis, MO", apiLevel = "1929", description = "Owned by PepsiCo", image = R.drawable.sevenup))
        versionList.add(Versions(codeName = "Gatorade", version = "Gainesville, FL", apiLevel = "1965", description = "Owned by PepsiCo", image = R.drawable.gatorade))
        versionList.add(Versions(codeName = "Quaker", version = "Akron, OH", apiLevel = "1877", description = "Owned by PepsiCo", image = R.drawable.quaker))
        versionList.add(Versions(codeName = "Cheetos", version = "San Antonio, TX", apiLevel = "1948", description = "Owned by PepsiCo", image = R.drawable.cheetos))
        versionList.add(Versions(codeName = "Ruffles", version = "New Bern, NC", apiLevel = "1948", description = "Owned by PepsiCo", image = R.drawable.ruffles))
        versionList.add(Versions(codeName = "Aquafina", version = "Wichita, KS", apiLevel = "1994", description = "Owned by PepsiCo", image = R.drawable.aquafina))

        // Brands under Frito-Lay
        versionList.add(Versions(codeName = "Fritos", version = "San Antonio, TX", apiLevel = "1932", description = "Owned by Frito-Lay", image = R.drawable.fritos))
        versionList.add(Versions(codeName = "Tostitos", version = "Plano, TX", apiLevel = "1978", description = "Owned by Frito-Lay", image = R.drawable.tostitos))
        versionList.add(Versions(codeName = "Sun Chips", version = "Plano, TX", apiLevel = "1991", description = "Owned by Frito-Lay", image = R.drawable.sunchips))
        versionList.add(Versions(codeName = "Cracker Jack", version = "Chicago, IL", apiLevel = "1873", description = "Owned by Frito-Lay", image = R.drawable.crackerjack))
        versionList.add(Versions(codeName = "Funyuns", version = "New Bern, NC", apiLevel = "1969", description = "Owned by Frito-Lay", image = R.drawable.funyuns))
        versionList.add(Versions(codeName = "Miss Vickie's", version = "Ontario, Canada", apiLevel = "1987", description = "Owned by Frito-Lay", image = R.drawable.missvickies))
        versionList.add(Versions(codeName = "Sabritones", version = "Mexico City, Mexico", apiLevel = "1943", description = "Owned by Frito-Lay", image = R.drawable.sabritones))
        versionList.add(Versions(codeName = "Rold Gold", version = "Philadelphia, PA", apiLevel = "1917", description = "Owned by Frito-Lay", image = R.drawable.roldgold))

        // Brands under Gatorade
        versionList.add(Versions(codeName = "Propel", version = "Gainesville, FL", apiLevel = "2000", description = "Owned by Gatorade", image = R.drawable.propel))
        versionList.add(Versions(codeName = "Bolt24", version = "Gainesville, FL", apiLevel = "2019", description = "Owned by Gatorade", image = R.drawable.bolt24))

        // Brands under Mars Inc.
        versionList.add(Versions(codeName = "M&M's", version = "Newark, NJ", apiLevel = "1941", description = "Owned by Mars Inc.", image = R.drawable.mandms))
        versionList.add(Versions(codeName = "Snickers", version = "Minneapolis, MN", apiLevel = "1930", description = "Owned by Mars Inc.", image = R.drawable.snickers))
        versionList.add(Versions(codeName = "Twix", version = "United Kingdom", apiLevel = "1967", description = "Owned by Mars Inc.", image = R.drawable.twix))
        versionList.add(Versions(codeName = "Milky Way", version = "Minneapolis, MN", apiLevel = "1924", description = "Owned by Mars Inc.", image = R.drawable.milkyway))
        versionList.add(Versions(codeName = "Skittles", version = "United Kingdom", apiLevel = "1974", description = "Owned by Mars Inc.", image = R.drawable.skittles))
    }
}