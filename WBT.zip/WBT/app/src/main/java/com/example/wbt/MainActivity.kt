package com.example.wbt

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    val versionList = ArrayList<Versions>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initData()
        setRecyclerView()
    }

    private fun setRecyclerView() {
        val versionAdapter = VersionAdapter(versionList)
        recyclerView.adapter = versionAdapter
        recyclerView.setHasFixedSize(true)
    }

    private fun initData() {
        versionList.add(Versions(
            codeName = "Apple Inc.",
            version = "Cupertino, CA",
            apiLevel = "Est. 1976",
            description = "No direct owners. Affiliated brands that are under Apple include Beats by Dre, Shazam, and NeXT."
        ))

        versionList.add(Versions(
            codeName = "Google",
            version = "Version 10",
            apiLevel = "Api Level 29",
            description = "This version list description"
        ))

        versionList.add(Versions(
            codeName = "Samsung",
            version = "Version 10",
            apiLevel = "Api Level 29",
            description = "This version list description"
        ))
    }
}